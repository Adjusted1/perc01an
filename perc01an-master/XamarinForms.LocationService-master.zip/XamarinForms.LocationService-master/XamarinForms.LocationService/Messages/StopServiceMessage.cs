﻿namespace XamarinForms.LocationService.Messages
{
    public class StopServiceMessage
    {
    }
}
