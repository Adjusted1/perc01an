﻿namespace XamarinForms.LocationService.Messages
{
    public class StartServiceMessage
    {
    }
}
