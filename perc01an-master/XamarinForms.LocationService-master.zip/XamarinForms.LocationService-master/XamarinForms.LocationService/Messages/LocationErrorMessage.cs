﻿namespace XamarinForms.LocationService.Messages
{
    public class LocationErrorMessage
    {
    }
}
