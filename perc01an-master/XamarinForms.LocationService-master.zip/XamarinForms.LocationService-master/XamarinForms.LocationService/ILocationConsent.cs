﻿using System.Threading.Tasks;

namespace XamarinForms.LocationService
{
    public interface ILocationConsent
    {
        Task GetLocationConsent();
    }
}
