﻿namespace XamarinForms.LocationService.Utils
{
    public static class Constants
    {
        public static readonly string SERVICE_STATUS_KEY = "service_status";
    }
}
